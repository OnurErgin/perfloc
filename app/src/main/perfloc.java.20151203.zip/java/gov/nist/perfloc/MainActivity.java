package gov.nist.perfloc;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.telephony.CellInfo;
import android.telephony.CellInfoCdma;
import android.telephony.CellInfoGsm;
import android.telephony.CellInfoLte;
import android.telephony.CellInfoWcdma;
import android.telephony.CellSignalStrengthCdma;
import android.telephony.CellSignalStrengthGsm;
import android.telephony.CellSignalStrengthLte;
import android.telephony.CellSignalStrengthWcdma;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import gov.nist.perfloc.WiFi.WiFiRSSIMeasurement;

public class MainActivity extends Activity {

    Vibrator v;
    private final Handler handler = new Handler();

    // View related definitions
    ListView SensorListView;
    ExpandableListView expListView;

    ToggleButton StartStopButton;

    TextView numAPs, WiFiScanTime;

    // Expandable List Adapter related definitions
    ExpandableListAdapter expListAdapter;
    List<String> listDataHeader;
    HashMap<String, List<String>> listDataChild;
    List<String> WiFiList, CellList, SensorList_text;

    // WiFi Scanning related definitions
    WifiManager wifi;
    String wifis[];
    WifiScanReceiver wifiReceiver;
    long time_prev, time_current, time_diff;
    int dot_current = 0;

    // Cell Tower and Telephony related definitions
    TelephonyManager tm;

    // Sensor related definitions
    HashMap<String, float[]> sensorHashMap;

    //SensorManager mSensorManager;
    //List<Sensor> sensorList;
    //float s_accelerometer[], s_gravity[], s_gyroscope[], s_proximity[], s_light[],
    //        s_magneticfield[], s_magneticfielduncalibrated[], s_geomagneticrotationvector[], s_rotationvector[], s_linearacceleration[];

    private ExecutorService pool;
    volatile int runFlag=0;

    volatile int numberOfAPs=0, WiFiScanDuration=0, numberOfCellTowers=0, numberOfSensors=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        v = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);

        StartStopButton = (ToggleButton) findViewById(R.id.toggleButton);

        numAPs = (TextView) findViewById(R.id.numAPs);
        WiFiScanTime = (TextView) findViewById(R.id.WiFiScanTime);

        expListView = (ExpandableListView) findViewById(R.id.expandableListView);

        // Initial view of the Expandable List View
        prepareListData();
        expListAdapter = new ExpandableListViewAdapter(getApplicationContext(), listDataHeader, listDataChild);
        expListView.setAdapter(expListAdapter);


        wifi=(WifiManager)getSystemService(Context.WIFI_SERVICE);
        wifiReceiver = new WifiScanReceiver();

        tm  = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

        final readBuiltinSensors rbs = new readBuiltinSensors(MainActivity.this, 10);
        pool = Executors.newFixedThreadPool(2);

        StartStopButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Thread tRBS = new Thread(rbs);
                if (isChecked) {
                    registerReceiver(wifiReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
                    wifi.startScan();

                    pool.execute(rbs);
                    Log.v("POOL: ", "Runnable executed.");
                } else {
                    unregisterReceiver(wifiReceiver);

                    rbs.terminate();
                    Log.v("POOL: ", "Runnable stopped.");
                }
                v.vibrate(500);
            }

        });
    }


    private void prepareListData() {
        listDataHeader = new ArrayList<String>();
        listDataChild = new HashMap<String, List<String>>();

        // Adding headers:
        listDataHeader.add(numberOfAPs + " Access Points, delay: " + WiFiScanDuration + "ms");
        listDataHeader.add(numberOfCellTowers + " Cell Towers");
        listDataHeader.add(numberOfSensors + " Sensors");

        // Adding child data
        //WiFiList = new ArrayList<String>();
        //CellList = new ArrayList<String>();
        //SensorList_text = new ArrayList<String>();

        listDataChild.put(listDataHeader.get(0), WiFiList);
        listDataChild.put(listDataHeader.get(1), CellList);
        listDataChild.put(listDataHeader.get(2), SensorList_text);

    }

    private class WifiScanReceiver extends BroadcastReceiver {
        public void onReceive(Context c, Intent intent) {
            /* Time frequency */
            time_prev = time_current;
            time_current = System.currentTimeMillis();
            time_diff = (time_current - time_prev);
            //WiFiScanTime.setText("\u0394".toUpperCase() + "t(ms):" + time_diff);

            /* Scan WiFi and display */
            List<ScanResult> wifiScanList = wifi.getScanResults();
            wifis = new String[wifiScanList.size()*2];

            for (int i = 0; i < wifiScanList.size(); i++) {
                //wifis[i] = ((wifiScanList.get(i)).SSID) + " " + ((wifiScanList.get(i)).BSSID) + " " + ((wifiScanList.get(i)).toString());
                wifis[i*2] = ((wifiScanList.get(i)).toString());

                // Test Protocol Buffers
                WiFiRSSIMeasurement.Builder wifi_info = WiFiRSSIMeasurement.newBuilder();
                wifi_info.setAp(WiFiRSSIMeasurement.AccessPoint.newBuilder()
                                .setBssi(wifiScanList.get(i).BSSID)
                                .setRssi(wifiScanList.get(i).level)
                );
                wifi_info.setMeasurementDevice(android.os.Build.MODEL);
                wifi_info.setTimestamp(time_current);
                wifi_info.setDotId(dot_current);
                // wifi_info.build().writeTo();
                //wifi_info.build().writeDelimitedTo(null);
                wifis[i*2 + 1] = wifi_info.toString();
            }
            wifi.startScan();

            numAPs.setText("# APs: " + wifiScanList.size());

            WiFiList = Arrays.asList(wifis);
            numberOfAPs = wifiScanList.size();
            WiFiScanDuration = (int) time_diff;

            // Get CellInfo and display
            boolean cellularSensingOn = true;
            if (cellularSensingOn) {

                List<CellInfo> cInfoList = tm.getAllCellInfo();

                String[] AllCellStrings = new String[cInfoList.size()];
                Integer CellDBM = new Integer(-999);
                String CellString = "not_yet_assigned";

                for (final CellInfo info : cInfoList) {
                    if (info instanceof CellInfoGsm) {
                        final CellSignalStrengthGsm gsm = ((CellInfoGsm) info).getCellSignalStrength();
                        // do what you need
                        CellString = "GSM: " + gsm.toString() + "\n" + ((CellInfoGsm) info).getCellIdentity();
                        //iRSS = gsm * 2 - 113;
                        CellDBM = gsm.getDbm();
                    } else if (info instanceof CellInfoCdma) {
                        final CellSignalStrengthCdma cdma = ((CellInfoCdma) info).getCellSignalStrength();
                        // do what you need
                        CellString = "CDMA: " + cdma.toString() + "\n" + ((CellInfoCdma) info).getCellIdentity();
                        //iRSS = cdma * 2 - 113;
                        CellDBM = cdma.getDbm();
                    } else if (info instanceof CellInfoLte) {
                        final CellSignalStrengthLte lte = ((CellInfoLte) info).getCellSignalStrength();
                        // do what you need
                        CellString = "LTE: " + lte.toString() + "\n" + ((CellInfoLte) info).getCellIdentity();
                        //iRSS = lte * 2 - 113;
                        CellDBM = lte.getDbm();
                    } else if (info instanceof CellInfoWcdma) {
                        final CellSignalStrengthWcdma wcdma = ((CellInfoWcdma) info).getCellSignalStrength();
                        // do what you need
                        CellString = "WCDMA: " + wcdma.toString() + "\n" + ((CellInfoWcdma) info).getCellIdentity();
                        //iRSS = wcdma * 2 - 113;
                        CellDBM = wcdma.getDbm();
                    } else {
                        CellString = "Unknown type of cell signal!";
                    }
                    AllCellStrings[cInfoList.indexOf(info)] = CellString + "\n DBMreading=" + CellDBM;
                }
                CellList = Arrays.asList(AllCellStrings);
                numberOfCellTowers = cInfoList.size();
            } else CellList = new ArrayList<String>();

            prepareListData();

            boolean WiFiGroupExpanded = expListView.isGroupExpanded(0);
            boolean CellGroupExpanded = expListView.isGroupExpanded(1);
            boolean SensorGroupExpanded = expListView.isGroupExpanded(2);

            expListAdapter = new ExpandableListViewAdapter(getApplicationContext(), listDataHeader, listDataChild);
            expListView.setAdapter(expListAdapter);

            if (WiFiGroupExpanded) expListView.expandGroup(0);
            if (CellGroupExpanded) expListView.expandGroup(1);
            if (SensorGroupExpanded) expListView.expandGroup(2);
        }
    }
    /* For ignoring Orientation change! */
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private class readBuiltinSensors implements Runnable {

        public Activity activity;

        private volatile boolean running;

        private volatile int measuringFrequency;

        // User motion bools
        private volatile boolean userRunning = false;
        private volatile boolean userTurning = false;


        SensorManager mSensorManager;

        List<Sensor> sensorList;

        volatile int flag = 0;

        float s_accelerometer[], s_gravity[], s_gyroscope[], s_proximity[], s_light[],
              s_magneticfield[], s_magneticfielduncalibrated[], s_geomagneticrotationvector[], s_rotationvector[], s_linearacceleration[];


        private SensorEventListener mSensorListener = new SensorEventListener() {

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {
            }

            @Override
            public void onSensorChanged(SensorEvent event) {
                Sensor cSensor = event.sensor;
                //noAPs_tv.setText("" + cSensor.getType());
                String sensorHashKey = event.sensor.getType() + ": " +  event.sensor.getStringType();
                //String sensorHashKey = event.sensor.getType() + ": " +  event.sensor.getName();
                //String sensorHashKey = event.sensor.getType() + "" ;
                sensorHashMap.put(sensorHashKey, event.values);
                if(event.sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {
                    float[] time_x = {(float) Calendar.getInstance().get(Calendar.SECOND)};
                    sensorHashMap.put(sensorHashKey, time_x);
                }
                switch (cSensor.getType()){
                    case Sensor.TYPE_ACCELEROMETER:
                        s_accelerometer = event.values; // 3 values
                        break;

                    case Sensor.TYPE_PROXIMITY:
                        s_proximity = event.values; // 1 value
                        break;

                    case Sensor.TYPE_LIGHT:
                        s_light = event.values; // 1 value
                        break;

                    case Sensor.TYPE_MAGNETIC_FIELD:
                        s_magneticfield = event.values; // ?? values
                        break;

                    case Sensor.TYPE_GYROSCOPE:
                        s_gyroscope = event.values; // 3 values
                        break;

                    case Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED:
                        s_magneticfielduncalibrated = event.values; // 6 values
                        break;

                    case Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR:
                        s_geomagneticrotationvector = event.values; // ?? values
                        break;

                    case Sensor.TYPE_ROTATION_VECTOR:
                        s_rotationvector = event.values; // 4 values
                        break;

                    case Sensor.TYPE_GRAVITY:
                        s_gravity = event.values; // 3 values
                        break;

                    case Sensor.TYPE_LINEAR_ACCELERATION:
                        s_linearacceleration = event.values; // 3 values
                        break;

                    case Sensor.TYPE_ORIENTATION: // Deprecated.
                        //TYPE_ORIENTATION is deprecated.  use SensorManager.getOrientation() instead.
                        break;

                    default:
                        //noAPs_tv.setText("Sensor error:" + cSensor.getName());
                        //DisplayRotation is unknown to me //Onur
                        break;

                }
            }
        };

        public void terminate() {
            running = false;
        }

        public void incrementFlag() {
            flag = flag +1;
        }

        public void setUserRunning (boolean action) {
            userRunning = action;
        }

        public void setUserTurning (boolean action) {
            userTurning = action;
        }

        public readBuiltinSensors(Activity _activity, int _measuringFrequency) {
            //this.activity = _activity;
            measuringFrequency = _measuringFrequency;

            //_slv = (ListView)findViewById(R.id.sensor_listView);

            mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            sensorList = mSensorManager.getSensorList(Sensor.TYPE_ALL);

            /* Below code is to remove wake-up sensors from sensorList
                List<Sensor> sensorsToRegister = new ArrayList<Sensor>();
                for (Sensor s : sensorList) {
                  if (!s.isWakeUpSensor())
                      sensorsToRegister.add(s);
                }
                sensorList = sensorsToRegister;
            */

            registerSensors(mSensorManager, sensorList);
            //numberOfSensors = sensorList.size();

            SensorList_text = new ArrayList<String>();
            sensorHashMap = new HashMap<String, float[]>();

            for (int i = 0; i < sensorList.size(); i++) {
                String sensorHashKey = sensorList.get(i).getType() + ": " + sensorList.get(i).getStringType();
                //String sensorHashKey = sensorList.get(i).getType() + ": " + sensorList.get(i).getName();
                //String sensorHashKey = sensorList.get(i).getType() + "";
                sensorHashMap.put(sensorHashKey, null);
                //SensorList_text.add("" + sensorList.get(i).getName());
            }

            List<String> keyList = new ArrayList<String>(sensorHashMap.keySet());
            SensorList_text = new ArrayList<String>();
            for (int i = 0; i < keyList.size();i++){
                SensorList_text.add(keyList.get(i) + ": " + Arrays.toString(sensorHashMap.get(keyList.get(i))));
            }
            numberOfSensors = sensorHashMap.size();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    //slv.setAdapter(new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, sensors));
                    WiFiScanTime.setText("Ready! " + Arrays.toString(s_light));

                    prepareListData();
                    expListAdapter = new ExpandableListViewAdapter(getApplicationContext(), listDataHeader, listDataChild);
                    expListView.setAdapter(expListAdapter);


                }
            });
        }

        @Override
        public void run() {
            //scanSwitch.toggle();

            running = true;


            while (running) {
                final String sensors[] = new String[5];
                sensors[0] = "Acceleration: " + Arrays.toString(s_accelerometer);
                sensors[1] = "Gyroscope: " + Arrays.toString(s_gyroscope);
                sensors[2] = "Magnetic Field: " + Arrays.toString(s_magneticfield);
                sensors[3] = "Light: " + Arrays.toString(s_light);
                sensors[4] = "Linear Acc.: " + Arrays.toString(s_linearacceleration);

                //SensorList_text = Arrays.asList(sensors);

                List<String> keyList = new ArrayList<String>(sensorHashMap.keySet());
                SensorList_text = new ArrayList<String>();
                for (int i = 0; i < keyList.size();i++){
                    SensorList_text.add(keyList.get(i) + ": " + Arrays.toString(sensorHashMap.get(keyList.get(i))));
                }

                Collections.sort(SensorList_text, String.CASE_INSENSITIVE_ORDER);

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        //slv.setAdapter(new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, sensors));
                        WiFiScanTime.setText(" Light: " + s_light[0]);

                        prepareListData();

                        /*boolean WiFiGroupExpanded = expListView.isGroupExpanded(0);
                        boolean CellGroupExpanded = expListView.isGroupExpanded(1);
                        boolean SensorGroupExpanded = expListView.isGroupExpanded(2);

                        expListAdapter = new ExpandableListViewAdapter(getApplicationContext(), listDataHeader, listDataChild);
                        expListView.setAdapter(expListAdapter);

                        if (WiFiGroupExpanded) expListView.expandGroup(0);
                        if (CellGroupExpanded) expListView.expandGroup(1);
                        if (SensorGroupExpanded) expListView.expandGroup(2);*/

                    }
                });

                try {
                    Thread.sleep(measuringFrequency);
                } catch (InterruptedException e) {
                    Log.e("THREAD_SLEEP", e.toString());
                }

                try {
                    String line = Math.ceil(System.currentTimeMillis() / 1) + " " + s_accelerometer[0] + " " + s_accelerometer[1] + " " + s_accelerometer[2] +
                            " " + s_gyroscope[0] + " " + s_gyroscope[1] + " " + s_gyroscope[2] + " " +
                            " " + userRunning + " " + userTurning + " " + flag + "\n";
                    //testFileWriter = new FileWriter(testFile);
                    //testFileWriter.append(line);
                    //testFileWriter.flush();
                    //fos.write(measurements.getBytes());
                    //Log.v("FILE_WRITE", line + " is written to " + testFile.getAbsolutePath());
                    //sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(outFile)));
                } catch (Exception e) {
                    Log.e("FILE", e.toString());
                }
            } // while running
            if (!running) {
                try {
                    //testFileWriter.flush();
                    //testFileWriter.close();
                    //Log.v("FILE_WRITE", "File writer closed: " + testFile.getAbsolutePath() + "\n");
                } catch (Exception e) {
                    Log.e("FILE", e.toString());
                }
            }
        }

        private void registerSensors (SensorManager tSensorManager, List<Sensor> listOfSensors){
            for (int i = 0; i < listOfSensors.size(); i++) {
                mSensorManager.registerListener(mSensorListener, listOfSensors.get(i),mSensorManager.SENSOR_DELAY_FASTEST);
            }
        }

        private class  SensorReading {
            public String sensorName;
            public int[] sensorValues;
        }


    }

}
